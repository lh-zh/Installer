
Pacote de idiomas Pointofix
-----------------------------

Inclui os seguintes ficheiros de tradu��o que podem ser editados com um editor de texto.

  (Ordem Alfab�tica)

    - pointofix_translation_ar.ini    - Arabic
    - pointofix_translation_el.ini    - N�a Ellinik�
    - pointofix_translation_en.ini    - English
    - pointofix_translation_es.ini    - Espa�ol
    - pointofix_translation_fr.ini    - Fran�ais
    - pointofix_translation_hr.ini    - Hrvatski
    - pointofix_translation_hu.ini    - Magyar
    - pointofix_translation_it.ini    - Italiano
    - pointofix_translation_jp.ini    - Japanese
    - pointofix_translation_nl.ini    - Nederlands
    - pointofix_translation_pl.ini    - Polski
    - pointofix_translation_pt-br.ini - Portugu�s do Brasil
    - pointofix_translation_pt-PT.ini - Portugu�s de Portugal
    - pointofix_translation_se.ini    - Svenska
    - pointofix_translation_tr.ini    - T�rk�e
    - pointofix_translation_zh-cn.ini - Chinese
    - pointofix_translation_zh-tw.ini - Taiwan / Chinese

    - Deutsch (Alem�o): 
      Ficheiro de lingua em Alem�o n�o � necess�rio porque � padr�o do Pointofix.



Como usar o pacote de idiomas Pointofix ?
-------------------------------------------

  1)  Primeiro, instale o Pointofix Alem�o vers�o 1.8.0 2017.02.18 (ou superior).

  2)  Em seguida, copie o ficheiro de tradu��o desejada (por exemplo, "pointofix_translation_en.ini"
      para a vers�o em Ingl�s) do pacote de idioma para a pasta do Pointofix
      (por exemplo: "C:\Program Files\Pointofix\").

  3)  Renomeie o ficheiro para "pointofix_translation.ini"
      (por exemplo, renomeie de "pointofix_translation_en.ini" para "pointofix_translation.ini")

  4)  Em seguida, reinicie Pointofix. Terminado!

  
    Observa��o:
      Se o seu sistema windows n�o mostra as extens�es de ficheiro, voc� deve ter em conta que, h� uma diferen�a entre o nome do ficheiro
      que voc� v� e o nome do ficheiro real. Ent�o se o seu idioma n�o funcionar, tente excluir a extens�o ".ini" e apenas renomeie
      o nome do ficheiro para "pointofix_translation" porque o seu sistema ir� adicionar a extens�o ".ini" automaticamente.


Traduzir para o seu idioma ?
------------------------------

  Mais tradu��es para outras l�nguas s�o muito bem-vindas.
  Se voc� gosta de traduzir, por favor, use o ficheiro de tradu��o em Ingl�s pointofix_translation_en.ini
  como modelo para a tradu��o e envie o seu ficheiro para info@pointofix.de para compartilhar com outros.

  Obrigado.


www.pointofix.de

